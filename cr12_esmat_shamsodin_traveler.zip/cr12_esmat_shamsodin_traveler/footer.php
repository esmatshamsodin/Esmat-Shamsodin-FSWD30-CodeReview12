	<footer>
			<div class="container fcontainer">
				<div class="row">
					<div class="col-lg-4 col-md-4 col-4 footer_text">
						<a href="#" ><h3 class="text-center">Facebook</h3>
						<img src="http://pluspng.com/img-png/png-facebook-logo-facebook-logo-png-300.png" width="100" height="80"></a>
					</div>
					<div class="col-lg-4 col-md-4 col-4 footer_text">
						<a href="#" ><h3 class="text-center">Company Location</h3>
						<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcStYlyQs_LzLFupe9fN8j4_SLL-XcJqRGnYWhedemieuuWlz4-s" width="60" height="60"></a>
					</div>
					<div class="col-lg-4 col-md-4 col-4 footer_text">
						<a href="#" ><h3 class="text-center">Instagram</h3>
						<img src="https://lh3.googleusercontent.com/aYbdIM1abwyVSUZLDKoE0CDZGRhlkpsaPOg9tNnBktUQYsXflwknnOn2Ge1Yr7rImGk=w300" width="60" height="60"></a>
					</div>
				</div>
			<hr>
			<h5>&copy <?php echo Date('Y'); ?> <?php bloginfo('name'); ?><?php echo('<br>')?><?php echo('Esmat Shamsodin')?> </h5>
			</div>
	</footer>
	
	<?php wp_footer(); ?>
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/css/bootstrap.js"></script>
</body>
</html>